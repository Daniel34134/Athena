"use client"

import { useState } from "react"
import { ArrowLeft, Languages, Download, Copy } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useRouter } from "next/navigation"

export default function TranslatePage() {
  const router = useRouter()
  const [selectedLanguage, setSelectedLanguage] = useState("chinese")

  return (
    <div className="flex flex-col min-h-screen bg-[url('/images/parchment-bg.jpg')] bg-cover">
      <header className="border-b border-amber-800/30 bg-amber-900/80 backdrop-blur-sm">
        <div className="container flex items-center h-16 px-4">
          <Button variant="ghost" size="icon" className="text-amber-100 mr-2" onClick={() => router.push("/")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-serif font-bold text-amber-100">Translate Document</h1>
        </div>
      </header>

      <main className="flex-1 container p-4 space-y-6">
        <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row gap-4 items-start">
              <div className="w-full sm:w-64 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-1">Target Language</label>
                  <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                    <SelectTrigger className="w-full bg-white border-amber-800/30">
                      <SelectValue placeholder="Select language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="chinese">Chinese (中文)</SelectItem>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="spanish">Spanish (Español)</SelectItem>
                      <SelectItem value="french">French (Français)</SelectItem>
                      <SelectItem value="german">German (Deutsch)</SelectItem>
                      <SelectItem value="japanese">Japanese (日本語)</SelectItem>
                      <SelectItem value="korean">Korean (한국어)</SelectItem>
                      <SelectItem value="russian">Russian (Русский)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-1">Translation Quality</label>
                  <Select defaultValue="high">
                    <SelectTrigger className="w-full bg-white border-amber-800/30">
                      <SelectValue placeholder="Select quality" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft (Faster)</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="high">High Quality</SelectItem>
                      <SelectItem value="professional">Professional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="pt-4">
                  <Button className="w-full bg-amber-900 hover:bg-amber-800 text-amber-50 font-serif">
                    Translate Now
                  </Button>
                </div>

                <div className="border-t border-amber-800/20 pt-4 mt-4">
                  <h3 className="text-sm font-medium text-amber-800 mb-2">Export Options</h3>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start border-amber-800/30 text-amber-900"
                    >
                      <Download className="mr-2 h-4 w-4" /> PDF
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full justify-start border-amber-800/30 text-amber-900"
                    >
                      <Copy className="mr-2 h-4 w-4" /> Copy Text
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex-1 border border-amber-800/30 rounded-lg overflow-hidden bg-white">
                <div className="bg-amber-100 p-3 border-b border-amber-800/30 flex justify-between items-center">
                  <div className="flex items-center">
                    <Languages className="h-5 w-5 text-amber-900 mr-2" />
                    <span className="font-medium text-amber-900">Translation Preview</span>
                  </div>
                  <Select defaultValue="page1">
                    <SelectTrigger className="h-8 text-xs border-amber-800/30 bg-white">
                      <SelectValue placeholder="Select page" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="page1">Page 1</SelectItem>
                      <SelectItem value="page2">Page 2</SelectItem>
                      <SelectItem value="page3">Page 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Tabs defaultValue="original" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-amber-100/50 border-b border-amber-800/30">
                    <TabsTrigger value="original" className="data-[state=active]:bg-white">
                      Original
                    </TabsTrigger>
                    <TabsTrigger value="translated" className="data-[state=active]:bg-white">
                      Translated
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="original" className="p-0">
                    <ScrollArea className="h-[500px] p-4">
                      <div className="space-y-4">
                        <h3 className="font-bold">Annual Business Report 2023</h3>
                        <p>
                          The fiscal year 2023 marked a significant milestone in our company's journey. Despite facing
                          unprecedented challenges in the global market, we managed to achieve substantial growth across
                          all our business segments.
                        </p>
                        <p>
                          Our revenue increased by 15% compared to the previous year, reaching $120 million. This growth
                          was primarily driven by our expansion into new markets and the launch of innovative products
                          that resonated well with our customers.
                        </p>
                        <h4 className="font-semibold mt-6">Key Achievements</h4>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>Expanded operations to 5 new countries</li>
                          <li>Launched 3 new product lines</li>
                          <li>Increased customer base by 22%</li>
                          <li>Reduced operational costs by 8%</li>
                        </ul>
                      </div>
                    </ScrollArea>
                  </TabsContent>
                  <TabsContent value="translated" className="p-0">
                    <ScrollArea className="h-[500px] p-4">
                      <div className="space-y-4">
                        <h3 className="font-bold">2023年度业务报告</h3>
                        <p>
                          2023财政年度是我们公司发展历程中的重要里程碑。尽管在全球市场面临前所未有的挑战，
                          我们仍然在所有业务领域实现了显著增长。
                        </p>
                        <p>
                          与上一年相比，我们的收入增长了15%，达到1.2亿美元。这一增长主要由我们拓展新市场
                          以及推出深受客户欢迎的创新产品所推动。
                        </p>
                        <h4 className="font-semibold mt-6">主要成就</h4>
                        <ul className="list-disc pl-5 space-y-1">
                          <li>将业务扩展到5个新国家</li>
                          <li>推出3条新产品线</li>
                          <li>客户群增加22%</li>
                          <li>运营成本降低8%</li>
                        </ul>
                      </div>
                    </ScrollArea>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <h3 className="text-lg font-serif font-semibold text-amber-900 mb-4">Translation History</h3>

            <div className="space-y-3">
              <div className="flex items-center p-3 rounded-lg border border-amber-800/20 bg-amber-100/50">
                <div className="h-10 w-10 rounded-full bg-amber-200 flex items-center justify-center text-amber-900 font-serif mr-3">
                  中
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-amber-900">Chinese Translation</h4>
                  <p className="text-xs text-amber-800/70">Completed on March 27, 2025</p>
                </div>
                <Button variant="outline" size="sm" className="border-amber-800/30 text-amber-900">
                  View
                </Button>
              </div>

              <div className="flex items-center p-3 rounded-lg border border-amber-800/20 bg-amber-100/50">
                <div className="h-10 w-10 rounded-full bg-amber-200 flex items-center justify-center text-amber-900 font-serif mr-3">
                  Es
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-amber-900">Spanish Translation</h4>
                  <p className="text-xs text-amber-800/70">Completed on March 25, 2025</p>
                </div>
                <Button variant="outline" size="sm" className="border-amber-800/30 text-amber-900">
                  View
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

