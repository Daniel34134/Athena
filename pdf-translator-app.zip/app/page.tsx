"use client"

import { useState } from "react"
import { Upload, FileText, Globe, Video, History, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useRouter } from "next/navigation"

export default function HomePage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState("translate")

  const handleUpload = () => {
    router.push("/upload-success")
  }

  return (
    <div className="flex flex-col min-h-screen bg-[url('/images/parchment-bg.jpg')] bg-cover">
      <header className="border-b border-amber-800/30 bg-amber-900/80 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16 px-4">
          <h1 className="text-xl font-serif font-bold text-amber-100">Chronos Translator</h1>
          <Button variant="ghost" size="icon" className="text-amber-100">
            <History className="h-5 w-5" />
          </Button>
        </div>
      </header>

      <main className="flex-1 container p-4 space-y-6">
        <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="text-center space-y-4 py-8">
              <div className="mx-auto bg-amber-900/10 w-20 h-20 rounded-full flex items-center justify-center border border-amber-800/30">
                <Upload className="h-10 w-10 text-amber-900" />
              </div>
              <h2 className="text-2xl font-serif font-semibold text-amber-900">Upload Your Document</h2>
              <p className="text-amber-800/80 max-w-md mx-auto">
                Upload a PDF to translate its content or generate a video
              </p>
              <Button onClick={handleUpload} className="mt-4 bg-amber-900 hover:bg-amber-800 text-amber-50 font-serif">
                Select PDF File
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
            <CardContent className="p-6 flex flex-col items-center text-center space-y-3">
              <div className="bg-amber-900/10 w-16 h-16 rounded-full flex items-center justify-center border border-amber-800/30">
                <Globe className="h-8 w-8 text-amber-900" />
              </div>
              <h3 className="text-xl font-serif font-semibold text-amber-900">Translate Documents</h3>
              <p className="text-amber-800/80">Translate your PDF into Chinese, English, and many other languages</p>
              <Button
                variant="outline"
                className="mt-2 border-amber-800/30 text-amber-900 font-serif"
                onClick={() => router.push("/translate")}
              >
                Explore <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
            <CardContent className="p-6 flex flex-col items-center text-center space-y-3">
              <div className="bg-amber-900/10 w-16 h-16 rounded-full flex items-center justify-center border border-amber-800/30">
                <Video className="h-8 w-8 text-amber-900" />
              </div>
              <h3 className="text-xl font-serif font-semibold text-amber-900">Generate Videos</h3>
              <p className="text-amber-800/80">Turn your PDF content into engaging videos automatically</p>
              <Button
                variant="outline"
                className="mt-2 border-amber-800/30 text-amber-900 font-serif"
                onClick={() => router.push("/video-generate")}
              >
                Explore <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <h3 className="text-lg font-serif font-semibold text-amber-900 mb-4">Recent Documents</h3>
            <div className="space-y-3">
              <div className="flex items-center p-3 rounded-lg border border-amber-800/20 bg-amber-100/50">
                <FileText className="h-5 w-5 text-amber-900 mr-3" />
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-amber-900">Annual Report 2023.pdf</h4>
                  <p className="text-xs text-amber-800/70">Translated to Chinese, English</p>
                </div>
                <Button variant="ghost" size="sm" className="text-amber-900">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>

              <div className="flex items-center p-3 rounded-lg border border-amber-800/20 bg-amber-100/50">
                <FileText className="h-5 w-5 text-amber-900 mr-3" />
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-amber-900">Research Paper.pdf</h4>
                  <p className="text-xs text-amber-800/70">Video generated</p>
                </div>
                <Button variant="ghost" size="sm" className="text-amber-900">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

