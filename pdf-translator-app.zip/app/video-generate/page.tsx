"use client"

import { useState } from "react"
import { ArrowLeft, Video, Settings, Play, Volume2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useRouter } from "next/navigation"

export default function VideoGeneratePage() {
  const router = useRouter()
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerate = () => {
    setIsGenerating(true)
    // Simulate generation process
    setTimeout(() => {
      setIsGenerating(false)
    }, 3000)
  }

  return (
    <div className="flex flex-col min-h-screen bg-[url('/images/parchment-bg.jpg')] bg-cover">
      <header className="border-b border-amber-800/30 bg-amber-900/80 backdrop-blur-sm">
        <div className="container flex items-center h-16 px-4">
          <Button variant="ghost" size="icon" className="text-amber-100 mr-2" onClick={() => router.push("/")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-xl font-serif font-bold text-amber-100">Generate Video</h1>
        </div>
      </header>

      <main className="flex-1 container p-4 space-y-6">
        <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row gap-4 items-start">
              <div className="w-full sm:w-64 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-1">Video Style</label>
                  <Select defaultValue="documentary">
                    <SelectTrigger className="w-full bg-white border-amber-800/30">
                      <SelectValue placeholder="Select style" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="documentary">Documentary</SelectItem>
                      <SelectItem value="presentation">Presentation</SelectItem>
                      <SelectItem value="tutorial">Tutorial</SelectItem>
                      <SelectItem value="animated">Animated</SelectItem>
                      <SelectItem value="historical">Historical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-1">Narrator Voice</label>
                  <Select defaultValue="male1">
                    <SelectTrigger className="w-full bg-white border-amber-800/30">
                      <SelectValue placeholder="Select voice" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male1">James (Male)</SelectItem>
                      <SelectItem value="female1">Emma (Female)</SelectItem>
                      <SelectItem value="male2">Michael (Male)</SelectItem>
                      <SelectItem value="female2">Sophia (Female)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-amber-800 mb-1">Video Length</label>
                  <Select defaultValue="auto">
                    <SelectTrigger className="w-full bg-white border-amber-800/30">
                      <SelectValue placeholder="Select length" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="auto">Auto (Based on content)</SelectItem>
                      <SelectItem value="short">Short (1-2 minutes)</SelectItem>
                      <SelectItem value="medium">Medium (3-5 minutes)</SelectItem>
                      <SelectItem value="long">Long (5-10 minutes)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-amber-800">Add Background Music</label>
                    <Switch id="music" />
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-amber-800">Include Captions</label>
                    <Switch id="captions" defaultChecked />
                  </div>
                </div>

                <div className="pt-4">
                  <Button
                    className="w-full bg-amber-900 hover:bg-amber-800 text-amber-50 font-serif"
                    onClick={handleGenerate}
                    disabled={isGenerating}
                  >
                    {isGenerating ? "Generating..." : "Generate Video"}
                  </Button>
                </div>
              </div>

              <div className="flex-1 border border-amber-800/30 rounded-lg overflow-hidden bg-white">
                <div className="bg-amber-100 p-3 border-b border-amber-800/30 flex justify-between items-center">
                  <div className="flex items-center">
                    <Video className="h-5 w-5 text-amber-900 mr-2" />
                    <span className="font-medium text-amber-900">Video Preview</span>
                  </div>
                  <Button variant="ghost" size="sm" className="h-8 text-amber-900">
                    <Settings className="h-4 w-4 mr-1" /> Settings
                  </Button>
                </div>

                <div className="aspect-video bg-amber-900/5 relative">
                  <div className="absolute inset-0 flex items-center justify-center flex-col">
                    <div className="w-16 h-16 rounded-full bg-amber-900/10 flex items-center justify-center mb-4">
                      <Video className="h-8 w-8 text-amber-900/60" />
                    </div>
                    <p className="text-amber-800/70 text-sm">
                      {isGenerating ? "Generating video preview..." : "Generate a video to see preview"}
                    </p>
                  </div>

                  {/* Video controls - would be functional in a real app */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-amber-900/30 to-transparent p-4">
                    <div className="flex items-center justify-between mb-2">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-white">
                        <Play className="h-4 w-4" />
                      </Button>
                      <div className="flex-1 mx-2">
                        <Slider defaultValue={[0]} max={100} step={1} className="h-1" />
                      </div>
                      <span className="text-xs text-white">0:00 / 3:45</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <Button variant="ghost" size="icon" className="h-6 w-6 text-white">
                        <Volume2 className="h-3 w-3" />
                      </Button>
                      <div className="w-20 mx-2">
                        <Slider defaultValue={[80]} max={100} step={1} className="h-1" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4">
                  <h3 className="font-medium text-amber-900 mb-2">Content Selection</h3>

                  <div className="space-y-2">
                    <div className="flex items-center p-2 rounded border border-amber-800/20 bg-amber-100/50">
                      <input type="checkbox" id="section1" className="mr-2" defaultChecked />
                      <label htmlFor="section1" className="text-sm text-amber-900">
                        Executive Summary
                      </label>
                    </div>
                    <div className="flex items-center p-2 rounded border border-amber-800/20 bg-amber-100/50">
                      <input type="checkbox" id="section2" className="mr-2" defaultChecked />
                      <label htmlFor="section2" className="text-sm text-amber-900">
                        Financial Highlights
                      </label>
                    </div>
                    <div className="flex items-center p-2 rounded border border-amber-800/20 bg-amber-100/50">
                      <input type="checkbox" id="section3" className="mr-2" defaultChecked />
                      <label htmlFor="section3" className="text-sm text-amber-900">
                        Market Analysis
                      </label>
                    </div>
                    <div className="flex items-center p-2 rounded border border-amber-800/20 bg-amber-100/50">
                      <input type="checkbox" id="section4" className="mr-2" />
                      <label htmlFor="section4" className="text-sm text-amber-900">
                        Future Outlook
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-amber-50/90 border-amber-800/30 backdrop-blur-sm">
          <CardContent className="p-6">
            <h3 className="text-lg font-serif font-semibold text-amber-900 mb-4">Generated Videos</h3>

            <div className="space-y-3">
              <div className="flex items-center p-3 rounded-lg border border-amber-800/20 bg-amber-100/50">
                <div className="h-14 w-24 bg-amber-200 rounded mr-3 overflow-hidden relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Play className="h-6 w-6 text-amber-900/70" />
                  </div>
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-amber-900">Annual Report Video</h4>
                  <p className="text-xs text-amber-800/70">3:45 • Generated on March 26, 2025</p>
                </div>
                <Button variant="outline" size="sm" className="border-amber-800/30 text-amber-900">
                  Download
                </Button>
              </div>

              <div className="flex items-center p-3 rounded-lg border border-amber-800/20 bg-amber-100/50">
                <div className="h-14 w-24 bg-amber-200 rounded mr-3 overflow-hidden relative">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Play className="h-6 w-6 text-amber-900/70" />
                  </div>
                </div>
                <div className="flex-1">
                  <h4 className="text-sm font-medium text-amber-900">Market Research Presentation</h4>
                  <p className="text-xs text-amber-800/70">5:12 • Generated on March 20, 2025</p>
                </div>
                <Button variant="outline" size="sm" className="border-amber-800/30 text-amber-900">
                  Download
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}

